# Instancing project starter

Used by the "Step by step" tutorial:

https://docs.godotengine.org/en/latest/getting_started/step_by_step/index.html
